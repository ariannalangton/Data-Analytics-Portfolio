This is the folder for all files pertainent to the air quality index analysis.
