This folder holds everything pertaining to the marketing budget analsys done.
