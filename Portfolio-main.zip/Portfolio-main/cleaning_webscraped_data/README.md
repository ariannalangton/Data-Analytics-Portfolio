Cleaning and formatting data to enter into a directory. More can be read on the main README file of this portfolio.
