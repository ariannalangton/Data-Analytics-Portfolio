This folder holds all notebooks created to analyze different unicorn companies and specific metrics pertaining to them. This is deescribed in more detail in the main portfolio README.
