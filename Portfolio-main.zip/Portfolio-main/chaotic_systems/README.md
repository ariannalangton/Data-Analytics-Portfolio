This is the folder for all files pertainent to the chaotic systems of differential equations research project.
