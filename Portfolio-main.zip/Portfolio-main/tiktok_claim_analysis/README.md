This is the folder for all files pertainent to the tiktok claim analsys project.
